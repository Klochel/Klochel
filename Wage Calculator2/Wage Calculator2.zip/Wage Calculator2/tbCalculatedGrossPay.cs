﻿namespace Wage_Calculator2
{
    internal class calculatedGrossPayLabel
    {
        public static string Text { get; internal set; }
    }
}